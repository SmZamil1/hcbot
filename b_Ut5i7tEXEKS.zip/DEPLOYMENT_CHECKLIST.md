# HopeCoin Bot - Deployment Checklist

## ✅ Pre-Deployment Verification

- [ ] All files downloaded from v0
- [ ] Project folder contains:
  - [ ] `config.php`
  - [ ] `index.html`
  - [ ] `database.sql`
  - [ ] `SETUP.md`
  - [ ] `QUICK_START.txt`
  - [ ] `bot/webhook.php`
  - [ ] `api/index.php`
  - [ ] `admin/index.php`

## 🔐 Configuration & Security

- [ ] Read SETUP.md completely
- [ ] Have InfinityFree credentials ready
- [ ] Have Telegram Bot Token: `8717172949:AAE926lCYq48dOPP8I5Y3EFNSL-3m_dWWDs`
- [ ] Know your Telegram User ID (for ADMIN_ID)
- [ ] Domain ready: `hopecoinbot.42web.io`

## 🗄️ Database Setup

- [ ] Created InfinityFree hosting account
- [ ] Created MySQL database in cPanel
- [ ] Created MySQL user with full privileges
- [ ] Have 4 credentials:
  - [ ] `sql200.infinityfree.com` (Host)
  - [ ] `if0_xxxxxx_hopecoin` (DB Name)
  - [ ] `if0_xxxxxx` (DB User)
  - [ ] Your strong password (DB Pass)
- [ ] Credentials securely recorded

## 📝 Configuration File

- [ ] Opened `config.php`
- [ ] Updated DB_HOST (sql200.infinityfree.com)
- [ ] Updated DB_NAME (from cPanel)
- [ ] Updated DB_USER (from cPanel)
- [ ] Updated DB_PASS (from cPanel)
- [ ] Updated BOT_TOKEN (verified correct)
- [ ] Updated ADMIN_ID (your Telegram ID)
- [ ] Updated MINI_APP_URL (https://hopecoinbot.42web.io)
- [ ] Updated BOT_USERNAME (hopecoinappbot)
- [ ] Saved config.php

## 📤 File Upload

- [ ] Connected to FTP (FileZilla or cPanel File Manager)
- [ ] Navigated to `/public_html/` directory
- [ ] Uploaded `config.php` to root
- [ ] Uploaded `index.html` to root
- [ ] Uploaded `database.sql` to root
- [ ] Uploaded `SETUP.md` to root
- [ ] Created `/bot/` folder
- [ ] Uploaded `bot/webhook.php` to `/bot/`
- [ ] Created `/api/` folder
- [ ] Uploaded `api/index.php` to `/api/`
- [ ] Created `/admin/` folder
- [ ] Uploaded `admin/index.php` to `/admin/`
- [ ] Verified all files are readable (permissions 644 or 755)

## 🗄️ Database Import

- [ ] Opened cPanel → phpMyAdmin
- [ ] Selected your database from left sidebar
- [ ] Clicked "Import" tab
- [ ] Clicked "Choose File" or dragged `database.sql`
- [ ] Clicked "Go" button
- [ ] Saw success message (tables created)
- [ ] Verified tables exist:
  - [ ] `users`
  - [ ] `game_plays`
  - [ ] `tasks`
  - [ ] `merge_boards`
  - [ ] `brain_game_queue`
  - [ ] `leaderboard_config`
  - [ ] `settings`

## 🤖 Telegram Bot Configuration

### Webhook Setup
- [ ] Opened this URL in browser (replace TOKEN):
  ```
  https://api.telegram.org/botTOKEN/setWebhook?url=https://hopecoinbot.42web.io/bot/webhook.php&drop_pending_updates=true
  ```
- [ ] Received response: `{"ok":true,"result":true}`

### Webhook Verification
- [ ] Opened this URL to verify:
  ```
  https://api.telegram.org/botTOKEN/getWebhookInfo
  ```
- [ ] Response shows:
  ```json
  {
    "ok":true,
    "result":{
      "url":"https://hopecoinbot.42web.io/bot/webhook.php",
      "has_custom_certificate":false,
      "pending_update_count":0
    }
  }
  ```

## 🧪 Bot Testing

- [ ] Opened Telegram
- [ ] Found bot: `@hopecoinappbot`
- [ ] Sent `/start` command
- [ ] Bot responded with welcome message
- [ ] Bot showed "Open App" button
- [ ] Clicked "Open App" button
- [ ] Mini app loaded successfully
- [ ] Mini app shows your name and coins
- [ ] Can tap the coin
- [ ] Coins increase when tapping
- [ ] Sent `/help` command
- [ ] Received command list
- [ ] Sent `/balance` command
- [ ] Received balance information
- [ ] Sent `/profile` command
- [ ] Received profile details

## 🎮 Mini App Testing

- [ ] App loads without errors
- [ ] Topbar shows name, level, coins
- [ ] Tap screen works - can tap coin
- [ ] Games screen shows 4 games
- [ ] Tasks screen displays tasks
- [ ] Leaderboard shows users (may be empty)
- [ ] Profile shows stats
- [ ] Navigation buttons work (bottom 5 tabs)
- [ ] All screens switch correctly

## 🔧 Admin Panel Testing

- [ ] Opened: `https://hopecoinbot.42web.io/admin/`
- [ ] Admin panel loaded (no auth error)
- [ ] Dashboard shows stats
- [ ] Users tab shows registered users
- [ ] Can search users
- [ ] Leaderboard displays users
- [ ] Tasks tab shows default tasks
- [ ] Can add new tasks
- [ ] Broadcast form present

## 🔄 24/7 Uptime Setup (RECOMMENDED)

- [ ] Visited https://uptimerobot.com
- [ ] Created free account
- [ ] Added monitor:
  - [ ] Type: HTTP(s)
  - [ ] URL: `https://hopecoinbot.42web.io/bot/webhook.php`
  - [ ] Interval: 5 minutes
  - [ ] Saved monitor
- [ ] Verified monitor is active
- [ ] Monitor shows "Up" status

## 🚀 Go Live Checklist

- [ ] All files uploaded
- [ ] Database working
- [ ] Webhook active
- [ ] Bot responds to commands
- [ ] Mini app loads and works
- [ ] Admin panel accessible
- [ ] UptimeRobot monitoring (optional but recommended)
- [ ] Ready to invite users!

## 📱 Production Ready?

- [ ] All core features working
- [ ] No console errors
- [ ] Database queries completing
- [ ] Bot responding instantly
- [ ] Mini app responsive on mobile
- [ ] Admin can manage system
- [ ] 24/7 uptime ensured (via UptimeRobot)

## 🎯 First 24 Hours

- [ ] Monitor bot activity in admin panel
- [ ] Check for any errors in cPanel logs
- [ ] Verify database is growing (users table)
- [ ] Test game play thoroughly
- [ ] Invite first test users
- [ ] Monitor performance
- [ ] Check UptimeRobot status
- [ ] Backup configuration

## 📊 Weekly Maintenance

- [ ] Check admin dashboard stats
- [ ] Verify webhook still active (`getWebhookInfo`)
- [ ] Monitor database size
- [ ] Review error logs
- [ ] Test all bot commands
- [ ] Verify UptimeRobot is pinging

## 💾 Backups

- [ ] Download config.php regularly
- [ ] Export database monthly (phpMyAdmin)
- [ ] Keep bot token secure (never share)
- [ ] Store credentials in password manager

## 🆘 Emergency Procedures

If bot goes down:
1. [ ] Check webhook status: `getWebhookInfo`
2. [ ] If down, re-set webhook URL
3. [ ] Check database connection in cPanel
4. [ ] Check server error logs
5. [ ] Verify UptimeRobot is still pinging
6. [ ] Check bot token hasn't been leaked

## ✨ Customization Ideas

After deployment, consider:
- [ ] Change game rewards in config.php
- [ ] Adjust leaderboard prizes (DAILY_PRIZES, WEEKLY_PRIZES)
- [ ] Add more tasks in database
- [ ] Create group rules in group management
- [ ] Customize welcome message
- [ ] Add referral campaign
- [ ] Create special events/tournaments

---

## 🎉 DEPLOYMENT COMPLETE!

Once all checkboxes are marked, your HopeCoin bot is:
- ✅ Running 24/7
- ✅ Connected to Telegram
- ✅ Fully functional
- ✅ Ready for users
- ✅ Monitored for uptime

**Congratulations! Your bot is live!** 🚀
